Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true
Config.EnableNonFreemodePeds      = false
Config.EnableCustomPeds           = false
Config.EnableLicenses             = true

Config.EnableHandcuffTimer        = true
Config.HandcuffTimer              = 10 * 60000

Config.EnableJobBlip              = true

Config.MaxInService               = 100
Config.Locale = 'es'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Coords  = vector3(425.1, -979.5, 30.7),
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(452.16, -992.89, 30.70)
		},

		Armories = {
			vector3(452.42, -980.08, 30.69)
		},

		Vehicles = {
			{
				Spawner = vector3(453.34, -1017.5, 28.4),
				InsideShop = vector3(228.5, -993.5, -99.5),
				SpawnPoints = {
					{ coords = vector3(438.4, -1018.3, 27.7), heading = 90.0, radius = 6.0 },
					{ coords = vector3(441.0, -1024.2, 28.3), heading = 90.0, radius = 6.0 },
					{ coords = vector3(453.5, -1022.2, 28.0), heading = 90.0, radius = 6.0 },
					{ coords = vector3(450.9, -1016.5, 28.1), heading = 90.0, radius = 6.0 }
				}
			},

			{
				Spawner = vector3(473.3, -1018.8, 28.0),
				InsideShop = vector3(228.5, -993.5, -99.0),
				SpawnPoints = {
					{ coords = vector3(475.9, -1021.6, 28.0), heading = 276.1, radius = 6.0 },
					{ coords = vector3(484.1, -1023.1, 27.5), heading = 302.5, radius = 6.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				InsideShop = vector3(477.0, -1106.4, 43.0),
				SpawnPoints = {
					{ coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(460.73, -985.55, 30.6)
		}

	}

}
Config.CustomPeds = {
    shared = {
        {label = 'DOEM', maleModel = 's_m_y_swat_01', femaleModel = 's_m_y_swat_01'},
       
    },

    recruit = {
    },

    officer = {
    },

    sergeant = {
    },

    lieutenant = {
    },

    sargento1 = {
    },

    auxiliar = {
    },

    mayor = {
    },

    scomisario = {
    },

    comisario = {
    },

    inspector = {
    },

    boss = {
     --   {label = 'SWAT Ped', maleModel = 's_m_y_swat_01', femaleModel = 's_m_y_swat_01'}
    },

    jefe = {
    },

    bullet_wear = {
    },

    gilet_wear = {
    },

    gilet_moto = {
    },
    gilet_infanteria = {
    },
    gilet_rangos = {
        },
    gilet_doem = { -- currently the same as chef_wear
        },

    bullet_wear = {
    },
    gilet_wear = {}
}

Config.AuthorizedWeapons = {
	shared = {
	  { weapon = 'WEAPON_NIGHTSTICK',    price = 0 },
      { weapon = 'WEAPON_PISTOL',     price = 0 },
      { weapon = 'WEAPON_HEAVYPISTOL',     price = 0 },
      { weapon = 'WEAPON_SMG',	price = 5000 },
      { weapon = 'WEAPON_STUNGUN',          price = 0 },
	  { weapon = 'WEAPON_SNIPERRIFLE',    price = 15000 },
	  { weapon = 'WEAPON_CARBINERIFLE',    price = 15000 },
	},
	
    recruit = {


    },

	officer = {

	},

	sergeant = {

	},

	lieutenant = {

	},

	sargentop = {

	},

	auxiliar = {

	},

	mayor = {

	},

	scomisario = {

	},

	comisario = {

	},

	inspector = {

	},

	boss = {

	},

	jefe = {

	}
}

Config.AuthorizedVehicles = {
	Shared = {
        { model = 'police', label = '--------=PATRULLAS--------', price = 1 },
		{ model = 'police2', label = 'Patrulla', price = 1 },		{ model = 'policeb', label = 'Moto', price = 1 },
		{ model = 'lspdunm', label = 'FBI Buffalo', price = 1 },
		{ model = 'rover', label = 'FBI Range rover', price = 1 },
		{ model = 'pol718', label = 'Porsche (rangos altos)', price = 1 },
		{ model = 'polmp4', label = 'Mclaren (rangos altos)', price = 1 },
		{ model = 'kawasaki', label = 'Moto kawasaki', price = 1 },

         },
  	recruit = {
		
	},

	officer = {

		
	},

	sergeant = {
        { model = 'police2', label = '--------=PATRULLAS--------', price = 1 },
		{ model = 'police2', label = 'Buffalo', price = 1 }
		-- { model = 'police2', label = 'Buffa', price = 1 },
         },
		


	lieutenant = {

		

	},

	sargentop = {

		

	},

	auxiliar = {

		

	},

	mayor = {

	},

	scomisario = {

		

	},

	comisario = {

		
	},

	inspector = {

		
	},

	boss = {

		

	},

	jefe = {	

		
	},


}		

Config.AuthorizedHelicopters = {
	Shared = {},
  	recruit = {},

	agente = {},

	agente1 = {
	},

	cabo = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 1 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 1 },
	},

	Cabo1 = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 1 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 1 },
	},

	cabomayor = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 1 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 1 },
	},

	sargento = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 1 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 1 },
	},

	sargento1 = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	Subteniente = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	teniente = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	Subins = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	inspector = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	InsJefe = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 0 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 0 },
	},

	boss = {
		{ model = 'polmav', label = 'Maverick', livery = 0, price = 1 },
		{ model = 'helicopterodoem', label = 'Maverick Doem', livery = 0, price = 1 },
	}
}

Config.Uniforms = {
	recruit = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 58,  tshirt_2 = 0,
			torso_1 = 55,   torso_2 = 0,
			decals_1 = 0,   decals_2 = 0,
			arms = 41,
			pants_1 = 25,   pants_2 = 0,
			shoes_1 = 25,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	officer = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 0,   decals_2 = 0,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	sergeant = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 1,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	lieutenant = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 2,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	sargentop = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},
	
	auxiliar = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	mayor = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	scomisario = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	comisario = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	inspector = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		}
	},

	boss = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 35,  tshirt_2 = 0,
			torso_1 = 48,   torso_2 = 0,
			decals_1 = 7,   decals_2 = 3,
			arms = 44,
			pants_1 = 34,   pants_2 = 0,
			shoes_1 = 27,   shoes_2 = 0,
			helmet_1 = -1,  helmet_2 = 0,
			chain_1 = 0,    chain_2 = 0,
			ears_1 = 2,     ears_2 = 0
		},
	},

	bullet_wear = {
		male = {
			bproof_1 = 11,  bproof_2 = 1
		},
		female = {
			bproof_1 = 13,  bproof_2 = 1
		}
	},

	gilet_wear = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 35,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] =-1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 2,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 36,  tshirt_2 = 1
		}
	},

	gilet_moto = {
		male = {
			['tshirt_1'] = 39,  ['tshirt_2'] = 0,
			['torso_1'] = 53,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 27,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 51,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = -1,  ['mask_2'] = 0,
			['bproof_1'] = 7,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		},
		female = {
			tshirt_1 = 36,  tshirt_2 = 1
		}
	},
	gilet_infanteria = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 208,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 87,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['mask_1'] = 35,  ['mask_2'] = 0,
			['bproof_1'] = 7,  ['bproof_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
		gilet_rangos = {
			male = {
				['tshirt_1'] = 1,  ['tshirt_2'] = 39,
				['torso_1'] = 242,   ['torso_2'] = 0,
				['decals_1'] = 0,   ['decals_2'] = 0,
				['arms'] = 30,
				['pants_1'] = 31,   ['pants_2'] = 2,
				['shoes_1'] = 25,   ['shoes_2'] = 0,
				['helmet_1'] = 60,  ['helmet_2'] = 9,
				['chain_1'] = 0,    ['chain_2'] = 0,
				['mask_1'] = -1,  ['mask_2'] = 0,
				['bproof_1'] = 7,  ['bproof_2'] = 0,
				['ears_1'] = 1,     ['ears_2'] = 0
			}
		},
			
		gilet_doem = { -- currently the same as chef_wear
		    male = {
				['tshirt_1'] = 57,  ['tshirt_2'] = 0,
				['torso_1'] = 98,   ['torso_2'] = 0,
				['decals_1'] = 0,   ['decals_2'] = 0,
				['arms'] = 0,
				['pants_1'] = 37,   ['pants_2'] = 0,
				['shoes_1'] = 62,   ['shoes_2'] = 0,
				['helmet_1'] = -1,  ['helmet_2'] = 0,
				['mask_1'] = 104,  ['mask_2'] = 25,
				['chain_1'] = 0,    ['chain_2'] = 0,
				['bproof_1'] = 9,  ['bproof_2'] = 0, 
				['bags_1'] = 0,    ['bags_2'] = 0,
				['ears_1'] = 1,     ['ears_2'] = 0
			}
		},
	
	bullet_wear = {
		male = {
			['bproof_1'] = 7,  ['bproof_2'] = 0
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['bproof_1'] = 10,  ['bproof_2'] = 0
		},
		female = {
			['bproof_1'] = 10,  ['bproof_2'] = 0
		}
	}

}